// Project - Code Optimization
// System Programming, DGIST, Prof. Yeseong Kim
// 
// You will not turn in this file, so do not need to modify it.
// Read the provided instruction carefully.

#ifndef _PROJ_H_
#define _PROJ_H_

void filter_optimized(void* args[]);

#endif
